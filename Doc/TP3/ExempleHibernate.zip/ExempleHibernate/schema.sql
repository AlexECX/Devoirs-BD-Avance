DROP TABLE Editeur
/
DROP TABLE Categorie
/
DROP TABLE Livre
/

CREATE TABLE Editeur
(nomEditeur 			VARCHAR(20),
 ville 				VARCHAR(20),
 PRIMARY KEY (nomEditeur)
)
/
CREATE TABLE Categorie
(code					VARCHAR(10),
 descripteur 			VARCHAR(20),
 codeParent				VARCHAR(10),
 PRIMARY KEY (code)
)
/
CREATE TABLE Livre
(ISBN 				CHAR(13),
 titre 				VARCHAR(50),
 anneeParution 			NUMBER(4),
 nomEditeur 			VARCHAR(20),
 code					VARCHAR(10),
 PRIMARY KEY (ISBN)
)
/
ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MON-YYYY'
/
ALTER SESSION SET NLS_DATE_LANGUAGE = ENGLISH
/

INSERT INTO Categorie VALUES('10','Sciences',NULL)
/
INSERT INTO Categorie VALUES('20','Philosophie',NULL)
/
INSERT INTO Categorie VALUES('30','Histoire', NULL)
/
INSERT INTO Categorie VALUES('40','Arts', NULL)
/
INSERT INTO Categorie VALUES('50','Litt�rature', NULL) 
/
INSERT INTO Categorie VALUES('101','Informatique','10')
/
INSERT INTO Categorie VALUES('102','Math�matiques','10')
/
INSERT INTO Categorie VALUES('103','Chimie','10')
/
INSERT INTO Categorie VALUES('501','Roman','50') 
/
INSERT INTO Categorie VALUES('502','Po�sie','50')
/
COMMIT
/
