package packExempleHib;

// Exemple de classe Livre
// Seule l'association avec l'�diteur est prise en compte pour fin d'illustration
public class Livre
{
	// Les attributs de la classe inlcuant les attributs pour r�aliser
	// les associations
	private	String		ISBN ;
	private	String		titre ;
	private	int	anneeParution ;

	// Pour l'association avec Editeur
	private	Editeur	editeur;

  // Constructeur vide requis
  public Livre(){}

	// Constructeur d'un livre
  public Livre(String ISBN, String titre, int anneeParution, Editeur editeur){
    this.ISBN = ISBN;
    this.titre = titre;
    this.anneeParution = anneeParution;
    this.editeur = editeur;
  }
  // Accesseurs
  public String getISBN(){return ISBN;}
  public String getTitre(){return titre;}
  public int getAnneeParution(){return anneeParution;}
  public Editeur getEditeur (){return editeur;}

  // Modifieurs
  public void setISBN(String ISBN){this.ISBN = ISBN;}
  public void setTitre(String titre){this.titre = titre;}
  public void setAnneeParution(int anneeParution){ 
    this.anneeParution = anneeParution;}
  public void setEditeur(Editeur editeur){
    this.editeur = editeur;
  }
}
