package packExempleHib;

import java.util.*;

// Exemple de classe Editeur

public class Editeur
{
	// Les attributs de la classe
	private String	nomEditeur ;
	private String	ville ;

	// La collection des livres de l'�diteur (pour l'association avec Livre)
	private Set		lesLivres = new HashSet();

	// Constructeur vide requis
	public Editeur(){}

	public Editeur(String nomEditeur, String	ville ){
		this.nomEditeur = nomEditeur;
		this.ville = ville;
	}
	
	// Lecteurs
	public String getNomEditeur(){return nomEditeur;}
	public String getVille(){return ville;}
	public Set getLesLivres(){return lesLivres;}

	// Modifieurs
	public void setNomEditeur(String nomEditeur){this.nomEditeur = nomEditeur;}
	public void setVille(String ville){this.ville = ville;}
	// Gestion explicite des associations par attributs
	public void setLesLivres(Set lesLivres ){
		this.lesLivres = lesLivres ;
	}
}
